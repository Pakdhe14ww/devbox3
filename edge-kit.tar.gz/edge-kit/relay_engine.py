#!/usr/bin/python3
"""
SafelinkU / sfl.gl bypass engine (v2).
Drives the real safelink state machine in a REAL Chrome (Patchright, channel=chromium):
  Open -> countdown -> Next -> [Turnstile] -> Go to Link -> final destination
Clicks are trusted CDP input events so ad/traffic attribution fires; pop-unders/pop-ups
are allowed to load (real ad impressions) then closed. The destination URL is taken from
the POST /api/go response body (authoritative) with location.href as fallback.

Run:  DISPLAY=:99 /usr/bin/python3 relay_engine.py "https://sfl.gl/XXXX"
"""
import os, sys, re, json, time, random, logging, threading
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
LOGDIR = os.path.join(HERE, "logs")
SHOTDIR = os.path.join(HERE, "shots")
os.makedirs(LOGDIR, exist_ok=True)
os.makedirs(SHOTDIR, exist_ok=True)

log = logging.getLogger("sl")
log.setLevel(logging.INFO)
_fh = logging.FileHandler(os.path.join(LOGDIR, "engine.log"))
_fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
_sh = logging.StreamHandler(sys.stdout)
_sh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
log.addHandler(_fh); log.addHandler(_sh)
log.propagate = False   # jangan dobel ke root logger milik sl_worker

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")

ACTION_TEXTS = ("Open", "Continue", "Next", "Go to Link", "Get Link")
INPUTISH = ("/api/",)

# --- wait budgets (measured, see logs): every click used to be followed by a fixed
# 60s poll, so one non-moving click cost a full minute. These are upper bounds; the
# poll exits on the first state change, so the real cost is far lower.
W_SUBMIT = 8.0    # Open/Next: overlay POSTs to the server, ~3s to be accepted
W_CONTD = 12.0    # Continue: navigates to a fresh article
W_GO = 20.0       # Go to Link: /api/go handshake + navigation to /ready/go
W_LOGIC = 4.0     # none of the above moved yet: stop stalling, retry/advance
WAITS = [("Next", W_SUBMIT), ("Go to Link", W_GO), ("Continue", W_CONTD)]
_shots = os.environ.get("SL_SHOTS", "1") not in ("0", "false", "")


def im_wait(label):
    for k, w in WAITS:
        if k in (label or ""):
            return w
    return W_SUBMIT
_ADS = None   # ads config scraped from the safelink overlay (popup/ad targets)
_LIST_CACHE = None  # (mtime, [credential lines]) untuk proxies.txt

# full-page popunder / onclick ad targets loaded inside the safelink overlay
def _is_sl_host(u):
    return "khaddavi" in u or "sfl.gl" in u


def human_move(page, x, y):
    try:
        vp = page.viewport_size or {"width": 1366, "height": 768}
        cx, cy = vp["width"] * random.uniform(0.3, 0.7), vp["height"] * random.uniform(0.4, 0.7)
        steps = random.randint(9, 18)
        for i in range(steps + 1):
            t = i / steps
            page.mouse.move(cx + (x - cx) * t + random.uniform(-7, 7),
                            cy + (y - cy) * t + random.uniform(-7, 7))
            time.sleep(random.uniform(0.008, 0.03))
    except Exception:
        pass


def click_human(page, loc):
    """Scroll into view, hover-move, then click with a trusted event."""
    loc.scroll_into_view_if_needed(timeout=8000)
    time.sleep(random.uniform(0.2, 0.5))
    try:
        box = loc.bounding_box()
        if box:
            vp = page.viewport_size or {"width": 1366, "height": 768}
            x = box["x"] + box["width"] / 2 + random.uniform(-6, 6)
            y = box["y"] + box["height"] / 2 + random.uniform(-4, 4)
            if 2 < y < vp["height"] - 2:
                human_move(page, x, y)
                time.sleep(random.uniform(0.05, 0.15))
                page.mouse.click(x, y)
                return True
    except Exception as e:
        log.warning("mouse click fallback: %s", e)
    loc.click(timeout=8000)
    return True


def scan(page):
    """Return (actionable_locator, label) or (None, label_of_visible_button)."""
    js = """() => [...document.querySelectorAll('#verify button, #second_open_placeholder button')]
        .map((b,i)=>{const r=b.getBoundingClientRect();
          return {i, text:(b.innerText||'').trim(), cls:b.className||'',
                  vis:r.width>1&&r.height>1, y:Math.round(r.y),
                  passcode: !!document.querySelector('input[name=passcode]'),
                  turnstile: !!document.querySelector('[name=\\"cf-turnstile-response\\"]')};})"""
    try:
        items = page.evaluate(js)
    except Exception:
        return None, None, {}
    meta = {}
    first_label = None
    for it in items:
        if not it["vis"]:
            continue
        meta = {"passcode": it["passcode"], "turnstile": it["turnstile"]}
        if first_label is None and it["text"]:
            first_label = it["text"]
        if it["text"] in ACTION_TEXTS and "wait" not in it["cls"]:
            loc = page.locator("#verify button, #second_open_placeholder button").nth(it["i"])
            return loc, it["text"], meta
    return None, first_label, meta


def drain_popups(popups, keep=3.5):
    for p in list(popups):
        try:
            if p.is_closed():
                popups.remove(p)
                continue
            p.wait_for_load_state("domcontentloaded", timeout=7000)
            u = p.url
            log.info("AD tab: %s", u[:120])
            time.sleep(random.uniform(1.2, keep))
            p.close()
        except Exception:
            if p in popups:
                popups.remove(p)


def drive_ad_popups(ctx, popups, keep=1.5):
    """Load a few real-ad tabs from the safelink ad rotator, view them briefly, close."""
    urls = []
    ads = _ADS or getattr(ctx, "_sl_ads", None)
    if ads:
        for k in ("notification_ads", "popup"):
            v = ads.get(k)
            if v:
                urls.append("https:" + v if v.startswith("//") else v)
        oc = ads.get("onclick") or {}
        if oc.get("go_to_link_button"):
            urls.append(oc["go_to_link_button"])
        if oc:
            urls.append(list(oc.values())[0])
    for u in urls[:2]:
        try:
            np = ctx.new_page()
            np.goto(u, wait_until="commit", timeout=12000)
            time.sleep(random.uniform(0.8, 1.2))
            np.close()
            log.info("drove ad tab: %s", u[:90])
        except Exception:
            pass
    drain_popups(popups, keep=1.2)


def solve_turnstile_if_any(page, meta, solvegate_key, deadline=25):
    """If the overlay carries a Turnstile widget, solve it via SolveGate."""
    if not meta.get("turnstile"):
        return
    import requests
    key = None
    try:
        key = page.evaluate("""() => {const e=document.querySelector('.cf-turnstile,[data-sitekey]');
            return e? (e.getAttribute('data-sitekey')||''):'';}""")
    except Exception:
        pass
    log.info("turnstile widget present, sitekey=%s", key)
    if not key or not solvegate_key:
        return
    try:
        r = requests.post("https://api.solvegate.io/v1/solve",
                          headers={"Authorization": f"Bearer {solvegate_key}",
                                   "Content-Type": "application/json"},
                          json={"gate": "turnstile", "sitekey": key, "url": page.url},
                          timeout=60)
        j = r.json()
        log.info("solvegate: %s", json.dumps(j)[:200])
        tok = j.get("token") or j.get("result")
        if j.get("status") == "solved" and tok:
            page.evaluate("""(t)=>{document.querySelectorAll('[name="cf-turnstile-response"]')
                .forEach(e=>{e.value=t;});}""", tok)
            log.info("turnstile token injected")
    except Exception as e:
        log.warning("solvegate failed: %s", e)


def _norm_cred(line):
    """Normalisasi satu baris jadi `user:pass@host:port`.

    Dua format diterima (BrightData ekspor dua-duanya):
      * host:port:user:pass      <- format daftar IP zone
      * user:pass@host:port
    -> None kalau tidak valid (baris di-skip, bukan bikin seluruh list gagal).
    """
    line = (line or "").strip()
    if not line:
        return None
    if "@" in line:
        cred, host = line.rsplit("@", 1)
        if ":" not in cred or ":" not in host:
            return None
        user, pwd = cred.split(":", 1)
        h, port = host.rsplit(":", 1)
        if not port.isdigit():
            return None
        return "%s:%s@%s:%s" % (user, pwd, h, port)
    parts = line.split(":")
    if len(parts) == 4 and parts[1].isdigit():
        h, port, user, pwd = parts
        return "%s:%s@%s:%s" % (user, pwd, h, port)
    return None


def _list_proxy():
    """Kredensial keluar untuk satu view, dibaca dari proxies.txt.

    Baris dipilih DETERMINISTIK lewat env SL_SHARD (1..N) supaya N job paralel
    tidak pernah memakai baris yang sama; tanpa SL_SHARD baris diacak per view.
    Tiap baris boleh memuat token `-session-...` yang diganti acak di
    build_proxy(), jadi tiap view tetap dapat IP keluar baru.
    """
    path = os.path.join(HERE, "proxies.txt")
    global _LIST_CACHE
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return None
    if not (_LIST_CACHE and _LIST_CACHE[0] == mtime and _LIST_CACHE[1]):
        try:
            with open(path) as fh:
                raw = [l.strip() for l in fh if l.strip() and not l.startswith("#")]
        except OSError:
            return None
        lines = [x for x in (_norm_cred(r) for r in raw) if x]
        if not lines:
            log.warning("proxies.txt: %d baris tapi tidak ada yang valid", len(raw))
            return None
        _LIST_CACHE = (mtime, lines)
        log.info("proxies.txt: %d kredensial siap pakai", len(lines))
    lines = _LIST_CACHE[1]
    shard = os.environ.get("SL_SHARD", "").strip()
    if shard.isdigit() and int(shard) > 0:
        return lines[(int(shard) - 1) % len(lines)]
    return random.choice(lines)


_MMDB_IPV4 = "/home/ubuntu/.cache/camoufox/geoip/mmdb/maxmind geolite2-ipv4.mmdb"
_MMDB_IPV4_ALT = "/home/runner/.cache/camoufox/geoip/mmdb/maxmind geolite2-ipv4.mmdb"


def proxy_country(proxy):
    """Kode negara (lowercase, mis. 'us'/'de') dari IP exit yang di-pin di
    username proxy. Dipakai supaya profil device (locale/timezone) COCOK dengan
    IP keluar — IP US dengan tz Asia/Jakarta itu sinyal bot yang jelas."""
    if not proxy:
        return None
    # zone rotating: negara ada eksplisit di username (tidak ada IP untuk di-lookup)
    m = re.search(r"-country-([a-zA-Z]{2})(?:-|$)", proxy.get("username") or "")
    if m:
        return m.group(1).lower()
    try:
        import maxminddb
        db = None
        for cand in (_MMDB_IPV4, _MMDB_IPV4_ALT):
            try:
                db = maxminddb.open_database(cand)
                break
            except Exception:
                db = None
        if db is None:
            return None
        ip = proxy["username"].split("-ip-")[-1]
        rec = db.get(ip) or {}
        db.close()
        return (rec.get("country_code") or "").lower() or None
    except Exception:
        return None


def build_proxy(country=None, session=None):
    """Proxy untuk satu view.

    Urutan sumber:
      1. proxies.txt  -> daftar kredensial siap pakai, IP exit di-pin di username
                         (dipakai kalau ada; rotasi acak tiap view)
      2. proxy.env    -> template dengan {country}/{session} disubstitusi
    Kalau dua-duanya kosong -> None (engine jalan tanpa proxy; worker sendiri
    sudah menahan view supaya tidak lewat IP server).
    """
    import uuid as _uuid
    # --- sumber utama untuk box ini: daftar kredensial fixed-IP -------------
    line = _list_proxy()
    if line:
        try:
            cred, host = line.rsplit("@", 1)
            user, pwd = cred.split(":", 1)
            # token session diganti acak tiap view: negara tetap (dari baris),
            # IP keluar selalu baru -> tidak kena dedupe "1 IP = 1 view/24 jam".
            if "-session-" in user:
                user = re.sub(r"-session-[^-]+", "-session-" + _uuid.uuid4().hex[:8], user)
            if ":" in host:
                h, port = host.rsplit(":", 1)
            else:
                h, port = host, "44445"
            return {"server": "http://%s:%s" % (h, port),
                    "username": user, "password": pwd}
        except Exception as e:
            log.warning("proxies.txt line tidak valid (%s): %s", line[:40], e)
    # --- sumber kedua: proxy.env (template {country}/{session}) -------------
    cfg = {}
    try:
        import proxy_config
        cfg = proxy_config.load()
    except Exception as e:
        log.warning("proxy_config load gagal: %s", e)
    tmpl = (cfg.get("PROXY_USER") or "").strip()
    pwd = (cfg.get("PROXY_PASS") or "").strip()
    host = (cfg.get("PROXY_HOST") or "").strip()
    port = (cfg.get("PROXY_PORT") or "").strip()
    country = country or (cfg.get("PROXY_COUNTRY") or "").strip() or None
    # --- fallback: env (dipakai kalau proxy.env belum ada / format lama) ----
    if not tmpl or not pwd:
        tmpl = os.environ.get("PROXY_USER_TEMPLATE", "")
        pwd = os.environ.get("PROXY_PASS", "")
        host = host or os.environ.get("PROXY_HOST", "brd.superproxy.io")
        port = port or os.environ.get("PROXY_PORT", "44445")
    if not tmpl or not pwd:
        return None
    host = host or "brd.superproxy.io"
    port = port or "44445"
    country = country or os.environ.get("PROXY_COUNTRY", "id")
    session = session or _uuid.uuid4().hex[:10]
    user = tmpl.replace("{country}", country).replace("{session}", session)
    return {"server": "http://%s:%s" % (host, port), "username": user, "password": pwd}


def bypass_guarded(url, hard_timeout=420, **kw):
    """Run bypass() under a HARD wall-clock cap.

    sync_playwright() can hang forever (chromium shutdown deadlock, stalled
    proxy socket). A Playwright timeout cannot interrupt a hung close(), so the
    worker loop freezes while systemd still reports the unit 'active' and the
    heartbeat... stops. Run the attempt in a daemon thread: on timeout we
    abandon it, kill stray chromium, and the worker loop keeps going.
    """
    import threading
    box = {}

    def _run():
        try:
            box["r"] = bypass(url, **kw)
        except Exception as e:                      # propagate to the caller
            box["e"] = e

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    t.join(hard_timeout)
    if t.is_alive():
        log.error("bypass exceeded hard timeout %ss -- abandoning attempt", hard_timeout)
        try:
            # Scoped: hanya chromium turunan PROSES INI. Dulu
            # `pkill -f 'chrome-linux64/chrome'` = kill semua chromium di box
            # (termasuk tugas lain yang jalan bersamaan).
            import proc_cleanup
            n, left = proc_cleanup.kill_own_chromium()
            log.info("scoped cleanup: killed=%d sisa=%d", n, left)
        except Exception as e:
            log.warning("scoped cleanup gagal: %s", e)
        return {"input": url, "final": None, "ok": False, "hops": [],
                "error": f"hard timeout {hard_timeout}s (browser hang)"}
    if "e" in box:
        raise box["e"]
    return box.get("r") or {"input": url, "final": None, "ok": False, "hops": [],
                            "error": "no result"}


def bypass_with_retry(url, attempts=3, country="id", use_proxy=True, **kw):
    """Try up to `attempts` times; rotate the proxy exit IP (and device profile)
    on every attempt. Residential exits are individually flaky, so a failure is
    usually a dead node, not a broken flow.

    Catatan: `country` di sini cuma dipakai kalau build_proxy() harus menyusun
    template {country} (proxy.env). Kalau pakai proxies.txt (IP di-pin), negara
    profil device diambil dari IP-nya sendiri lewat proxy_country(), supaya
    locale/timezone tidak bertentangan dengan IP keluar.
    """
    hard = kw.pop("hard_timeout", 420)
    on_attempt = kw.pop("on_attempt", None)   # progress reporter: one view != one attempt
    last = None
    for i in range(attempts):
        if on_attempt:
            try:
                on_attempt()
            except Exception:
                pass
        proxy = None
        if use_proxy:
            proxy = build_proxy(country=country)
            if proxy:
                log.info("attempt %d/%d via %s", i + 1, attempts, proxy["username"][:70])
        # profil device mengikuti negara IP exit, bukan country default job
        prof_country = proxy_country(proxy) or country
        r = bypass_guarded(url, hard_timeout=hard, proxy=proxy,
                           country=prof_country, **kw)
        r["attempt"] = i + 1
        r["proxy_user"] = (proxy or {}).get("username")
        if r.get("ok"):
            return r
        last = r
        log.warning("attempt %d failed (%s); retrying with a new IP",
                    i + 1, r.get("error") or "no destination")
        time.sleep(random.uniform(2, 5))
    return last


def bypass(url, headless=False, max_loop=16, shot_prefix="run", solvegate_key=None,
           proxy=None, profile=None, country="id"):
    """Resolve a safelink. Each call uses a fresh device profile + fresh browser
    profile dir so the fingerprint hash and cookies are unique per view."""
    import profile_spoof
    if profile is None:
        profile = profile_spoof.pick_profile(country=country)
    result = {"input": url, "final": None, "ok": False, "hops": [], "error": None,
              "api_go": [], "device": {
                  "ua": profile["ua"], "platform": profile["platform"],
                  "screen": profile["screen"], "renderer": profile["renderer"],
                  "tz": profile["tz"], "seed": profile["seed"]}}
    popups = []
    stop = [False]          # keepalive thread's kill switch (set before ctx.close())
    prof_dir = profile_spoof.profile_dir()
    os.makedirs(prof_dir, exist_ok=True)
    sw, sh = profile["screen"]
    with sync_playwright() as pw:
        kw = dict(headless=headless, channel="chromium",
                  viewport={"width": 1280, "height": max(720, sh - 40)},
                  user_agent=profile["ua"],
                  locale=profile["lang"], timezone_id=profile["tz"],
                  args=["--disable-blink-features=AutomationControlled", "--no-first-run",
                        "--no-default-browser-check", "--disable-dev-shm-usage",
                        "--disable-popup-blocking",
                        # Xvfb has no GPU: without this WebGL is null, which is a
                        # blatant bot signal (real phones/PCs always expose WebGL).
                        # The init script overrides the SwiftShader strings below.
                        # package renderer saat container dibuat (window lebih
                        # ringan, Xvfb :99 1920x1080 tetap dipakai).
                        "--enable-unsafe-swiftshader",
                        # --- hemat RAM/CPU: switch standalone saja (JANGAN
                        # kirim --disable-features kedua: Chromium hanya memakai
                        # occurrence TERAKHIR, jadi flag milik Playwright hilang).
                        # Service audio/speech masing-masing spawn process
                        # (~90MB RSS) dan di sini tidak ada suara yang dipakai.
                        "--mute-audio",
                        "--disable-audio-output",
                        "--disable-speech-api",
                        "--force-device-scale-factor=1",
                        # Boot noise that costs real seconds on a 2-vCPU box: component
                        # update checks, background networking, sync, metrics upload.
                        # None of them affect the view; each one is a stalled socket
                        # through a residential proxy.
                        "--disable-background-networking",
                        "--disable-component-update",
                        "--disable-domain-reliability",
                        "--disable-sync",
                        "--metrics-recording-only",
                        # long article pages lazy-load dozens of images below the fold;
                        # they are never seen (we only click the overlay) but they keep
                        # the tab busy for tens of seconds on swiftshader.
                        "--disable-lazy-loading",
                        "--window-size=%d,%d" % (1280, max(720, sh - 40))],
                  ignore_default_args=["--enable-automation"])
        if proxy:
            kw["proxy"] = proxy if isinstance(proxy, dict) else {"server": proxy}
        # CATATAN: FormControlsRefresh (snapshot form di tiap POST page-world)
        # TIDAK bisa dimatikan lewat argumen terpisah — harus masuk ke
        # --disable-features, dan arg itu sudah dipakai Playwright (occurrence
        # terakhir menang). Overhead-nya nyata tapi lebih baik dibiarkan daripada
        # kehilangan flag anti-detection Playwright.
        ctx = pw.chromium.launch_persistent_context(user_data_dir=prof_dir, **kw)
        try:
            ctx.add_init_script(profile_spoof.init_js(profile))
            # The safelink article retitles the tab to "SafelinkU / sfl.gl ...",
            # which rewrites the X11 WM name and leaks the bot's purpose into the
            # host window list. Pin document.title.
            ctx.add_init_script(
                "Object.defineProperty(document,'title',{get:function(){"
                "var t=document.querySelector('title');"
                "return t?t.textContent:'';},configurable:true});")
        except Exception as e:
            log.warning("init_script failed: %s", e)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.on("page", lambda p: popups.append(p))

        def on_resp(r):
            if "/api/go" in r.url or "/api/verify" in r.url:
                try:
                    result["api_go"].append({"url": r.url, "status": r.status,
                                             "body": r.text()[:400]})
                except Exception:
                    pass
        page.on("response", on_resp)

        entry_host = urlparse(url).netloc

        # --- keepalive: warm the ad-network socket once and keep re-warming it -----
        # The site probes adsbygoogle.js content-length for its AdBlock gate. A cold
        # (per-context) socket through a residential exit adds seconds to that probe.
        # NOTE: chromium writes the cookie itself in-browser; playwright's APIRequest
        # shares no cookie jar with the loaded page, so it must NOT be used to warm
        # the page's own state -- only to keep the proxy tunnel + DNS hot.
        def keepalive():
            while not stop[0]:
                try:
                    ctx.request.get(
                        "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js",
                        timeout=12000)
                except Exception:
                    pass
                for _ in range(30):
                    if stop[0]:
                        return
                    time.sleep(0.5)

        threading.Thread(target=keepalive, daemon=True).start()

        # land like a real visitor: warm up a referer, then go to the link.
        # wait_until="commit" + short timeout: a dead residential exit must fail in
        # ~10s, not burn the full 30s timeout on a warmup that is not required.
        try:
            page.goto("https://www.google.com/", wait_until="commit", timeout=10000)
            time.sleep(random.uniform(0.35, 0.9))
            page.goto("https://safelinku.com/", wait_until="commit", timeout=12000)
            time.sleep(random.uniform(0.3, 0.7))
        except Exception as e:
            log.info("warmup skipped: %s", str(e)[:70])
        try:
            page.goto(url, wait_until="commit", timeout=30000)
        except Exception as e:
            log.warning("goto: %s", e)
        result["hops"].append(page.url)
        log.info("entry=%s landed=%s", url, page.url)

        try:
            # measured 3.5s end-to-end through the de ISP pool; 45s only turned a
            # dead view into a 45s wait before the same failure.
            page.wait_for_selector("#verify button, #second_open_placeholder button", timeout=25000)
        except Exception as e:
            result["error"] = "overlay never rendered"
            log.error(result["error"])
            try: page.screenshot(path=os.path.join(SHOTDIR, f"{shot_prefix}_nooverlay.png"))
            except Exception: pass
            stop[0] = True
            ctx.close(); return result

        # capture the ad rotator config for real ad-impression tabs
        global _ADS
        try:
            a = page.evaluate("() => (typeof ads !== 'undefined') ? ads : null")
        except Exception:
            a = None
        if not a:
            try:
                html = page.content()
                key = "const ads ="
                i = html.find(key)
                if i != -1:
                    j = html.find("{", i)
                    depth, k = 0, j
                    while k < len(html):
                        if html[k] == "{":
                            depth += 1
                        elif html[k] == "}":
                            depth -= 1
                            if depth == 0:
                                break
                        k += 1
                    a = json.loads(html[j:k + 1])   # \/ is valid JSON
            except Exception as e:
                log.warning("ads parse failed: %s", e)
        if a:
            _ADS = a
            log.info("ads rotator captured: %s", json.dumps(a)[:250])
            result["ads"] = a

        clicked = 0
        t_start = time.time()
        step = 0
        while clicked < 8 and time.time() - t_start < 200:
            drain_popups(popups, keep=1.0)
            # Only a /ready/go navigation counts as done. The safelink articles carry
            # AdSense/redirect ads that can hijack the MAIN tab to a spam domain
            # (adult/vpn landing) — that is an ad, NOT the destination. Never accept
            # an off-host URL here; navigating away is handled below via logs.
            if "/ready/go" in page.url:
                result["final"] = page.url
                break
            loc, label, meta = scan(page)
            if loc is None:
                # countdown ("Wait... Ns") or captcha gate — solve if a widget is present
                if meta.get("turnstile"):
                    solve_turnstile_if_any(page, meta, solvegate_key)
                time.sleep(0.5)
                continue
            wait = im_wait(label)
            try:
                click_human(page, loc)
            except Exception as e:
                log.warning("click err: %s", e)
                time.sleep(0.5)
                continue
            clicked += 1
            result["hops"].append(f"click:{label}")
            log.info("click #%d label=%r url=%s", clicked, label, page.url[:110])
            if _shots:
                try:
                    page.screenshot(path=os.path.join(SHOTDIR, f"{shot_prefix}_c{clicked}.png"))
                except Exception:
                    pass

            # Wait for the overlay to move on. The old code polled a fixed 60s after
            # EVERY click, so any click whose label merely re-rendered (same text)
            # burned 60s wall clock per iteration. Exit as soon as anything moved:
            # next actionable label, countdown class, hijack, or /ready/go.
            t0 = time.time()
            deadline = max(wait, W_SUBMIT if label in ("Open", "Next") else W_LOGIC)
            while time.time() - t0 < deadline:
                drain_popups(popups, keep=0.6)
                if "/ready/go" in page.url:
                    break
                cur = urlparse(page.url).netloc
                if cur not in (entry_host, "app.khaddavi.net"):
                    log.info("main tab hijacked to %s -> back()", page.url[:90])
                    try:
                        page.go_back(wait_until="commit", timeout=15000)
                        time.sleep(0.4)
                    except Exception:
                        pass
                    break
                loc2, lab2, meta2 = scan(page)
                if lab2 and lab2 != label:
                    break
                if meta2.get("turnstile"):
                    solve_turnstile_if_any(page, meta2, solvegate_key)
                time.sleep(0.4)
            if "/ready/go" in page.url:
                result["final"] = page.url
                break
            step += 1
            if step > 40:
                break

        if not result["final"]:
            result["final"] = page.url
        # Fallback ONLY: if the state machine never reached /ready/go, the POST
        # /api/go response body already carries the publisher URL. It must not be
        # used on the happy path: the /ready/go page + final click is what fires the
        # publisher's view counter.
        if "/ready/go" not in (result["final"] or ""):
            for rec in result["api_go"]:
                m = re.search(r'"(?:target|url)"\s*:\s*"([^"]+)"', rec.get("body") or "")
                if m and "/api/go" in rec.get("url", "") and "khaddavi" not in m.group(1):
                    t = m.group(1).replace("\\/", "/")
                    if not _is_sl_host(t):
                        result["final"] = t
                        result["ok"] = True
                        break

        # follow the one-time /ready/go token to the publisher's real destination
        # (this is the ONLY path that yields a valid destination; an off-host URL
        #  in the main tab is an ad hijack, never the publisher's page)
        if "/ready/go" in (result["final"] or ""):
            try:
                log.info("following ready/go -> %s", result["final"][:110])
                page.goto(result["final"], wait_until="commit", timeout=30000)
                # the handler is inline in the served HTML; wait for the button text
                # itself (2s flat before was both slower and less reliable)
                try:
                    page.wait_for_selector("text=OPEN LINK", timeout=8000)
                except Exception:
                    pass
                time.sleep(0.25)

                # Resolve the destination BEFORE clicking: the inline handler holds it
                # and the click navigates the page away (so parse order matters).
                dest = None
                try:
                    html = page.content()
                    m = re.search(r'location\.href\s*=\s*"([^"]+)"', html)
                    if m:
                        dest = m.group(1).replace("\\/", "/")
                except Exception:
                    pass

                # Honour the final click (real user gesture, fires the final ad + the
                # publisher's view counter), then fall back to the parsed URL.
                try:
                    btn = page.locator("button", has_text="OPEN LINK").first
                    if btn.count() == 0:
                        btn = page.locator("button").first
                    if btn.count():
                        click_human(page, btn)
                        log.info("clicked OPEN LINK")
                        time.sleep(1.0)
                except Exception as e:
                    log.warning("OPEN LINK click: %s", e)

                if dest and "sfl.gl" not in dest:
                    log.info("destination resolved: %s", dest[:140])
                    result["final"] = dest
                    result["ok"] = True
                else:
                    # /ready/go is a safelink URL, so an off-sfl.gl URL here only
                    # appears if the final click navigated us to the publisher.
                    if "sfl.gl" not in page.url and "khaddavi" not in page.url:
                        result["final"] = page.url
                        result["ok"] = True
                drive_ad_popups(ctx, popups)
            except Exception as e:
                log.warning("ready/go follow failed: %s", e)
        result["hops"].append("final:" + (result["final"] or ""))
        if _shots:
            try: page.screenshot(path=os.path.join(SHOTDIR, f"{shot_prefix}_final.png"))
            except Exception: pass
        else:
            if result.get("_desturl"):
                result["hops"].append("dest:" + result.pop("_desturl"))
        drain_popups(popups, keep=0.6)
        stop[0] = True
        ctx.close()
    # clean up the throwaway browser profile (one device = one profile dir)
    try:
        import shutil
        shutil.rmtree(prof_dir, ignore_errors=True)
    except Exception:
        pass
    return result


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "https://sfl.gl/PpJU"
    sg = os.environ.get("SOLVEGATE_API_KEY")
    r = bypass(target, headless=False, shot_prefix="test", solvegate_key=sg)
    print("\n=== RESULT ===")
    print(json.dumps(r, indent=2, ensure_ascii=False)[:2500])